
package net.mcreator.workspace.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.workspace.entity.DerpigEntity;
import net.mcreator.workspace.client.model.ModelAnimatedWardenPigModel;

import com.mojang.blaze3d.vertex.PoseStack;

public class DerpigRenderer extends MobRenderer<DerpigEntity, ModelAnimatedWardenPigModel<DerpigEntity>> {
	public DerpigRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelAnimatedWardenPigModel(context.bakeLayer(ModelAnimatedWardenPigModel.LAYER_LOCATION)), 0.5f);
		this.addLayer(new ItemInHandLayer<>(this));
	}

	protected void scale(DerpigEntity p_115983_, PoseStack p_115984_, float p_115985_) {
		this.shadowRadius = 0.5f * p_115983_.getScale();
		p_115984_.scale(p_115983_.getScale(), p_115983_.getScale(), p_115983_.getScale());
	}

	@Override
	public ResourceLocation getTextureLocation(DerpigEntity entity) {
		return new ResourceLocation("workspace:textures/derpig" + entity.getColor() + ".png");
	}
}
