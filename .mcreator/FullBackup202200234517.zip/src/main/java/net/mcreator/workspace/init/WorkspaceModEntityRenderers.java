
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.workspace.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.workspace.client.renderer.ZombiefiedChadVillagerRenderer;
import net.mcreator.workspace.client.renderer.ZombieVindicatorRenderer;
import net.mcreator.workspace.client.renderer.ZombieRavagerRenderer;
import net.mcreator.workspace.client.renderer.ZombiePillagerRenderer;
import net.mcreator.workspace.client.renderer.ZombiePigRenderer;
import net.mcreator.workspace.client.renderer.ZombieEvokerRenderer;
import net.mcreator.workspace.client.renderer.ZombieCowRenderer;
import net.mcreator.workspace.client.renderer.VehiclePhantomRenderer;
import net.mcreator.workspace.client.renderer.TamedPhantomRenderer;
import net.mcreator.workspace.client.renderer.TRabusRenderer;
import net.mcreator.workspace.client.renderer.RedstonePoweredIronGolemRenderer;
import net.mcreator.workspace.client.renderer.RedstoneBombRenderer;
import net.mcreator.workspace.client.renderer.RavagerEndermanRenderer;
import net.mcreator.workspace.client.renderer.PigBruteRenderer;
import net.mcreator.workspace.client.renderer.PhantomTamerRenderer;
import net.mcreator.workspace.client.renderer.PavagerRenderer;
import net.mcreator.workspace.client.renderer.MinionRedstoneGolemRenderer;
import net.mcreator.workspace.client.renderer.InsomniaLumpRenderer;
import net.mcreator.workspace.client.renderer.ExplosivePhantomRenderer;
import net.mcreator.workspace.client.renderer.EnderRavagerRenderer;
import net.mcreator.workspace.client.renderer.EliteEnderRavagerRenderer;
import net.mcreator.workspace.client.renderer.DerpigRenderer;
import net.mcreator.workspace.client.renderer.CyborgVindicatorRenderer;
import net.mcreator.workspace.client.renderer.CrudeRedstoneMonstrosityRenderer;
import net.mcreator.workspace.client.renderer.CrudeRedstoneGolemRenderer;
import net.mcreator.workspace.client.renderer.CreepigRenderer;
import net.mcreator.workspace.client.renderer.CreeperGolemRenderer;
import net.mcreator.workspace.client.renderer.ChadVillagerRenderer;
import net.mcreator.workspace.client.renderer.BigSnowGolemRenderer;
import net.mcreator.workspace.client.renderer.BigSnowBallRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class WorkspaceModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(WorkspaceModEntities.CHAD_VILLAGER.get(), ChadVillagerRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.PAVAGER.get(), PavagerRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.ENDER_RAVAGER.get(), EnderRavagerRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.ELITE_ENDER_RAVAGER.get(), EliteEnderRavagerRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.T_RABUS.get(), TRabusRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.RAVAGER_ENDERMAN.get(), RavagerEndermanRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.DERPIG.get(), DerpigRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.PIG_BRUTE.get(), PigBruteRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.ZOMBIE_COW.get(), ZombieCowRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.ZOMBIE_PIG.get(), ZombiePigRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.ZOMBIEFIED_CHAD_VILLAGER.get(), ZombiefiedChadVillagerRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.REDSTONE_POWERED_IRON_GOLEM.get(), RedstonePoweredIronGolemRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.CYBORG_VINDICATOR.get(), CyborgVindicatorRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.CRUDE_REDSTONE_GOLEM.get(), CrudeRedstoneGolemRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.CRUDE_REDSTONE_MONSTROSITY.get(), CrudeRedstoneMonstrosityRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.MINION_REDSTONE_GOLEM.get(), MinionRedstoneGolemRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.REDSTONE_BOMB.get(), RedstoneBombRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.BIG_SNOW_GOLEM.get(), BigSnowGolemRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.BIG_SNOW_BALL.get(), BigSnowBallRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.HARDENED_SNOW_BALL.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.EARTH_QUAKE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.ZOMBIE_VINDICATOR.get(), ZombieVindicatorRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.ZOMBIE_PILLAGER.get(), ZombiePillagerRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.TAMED_PHANTOM.get(), TamedPhantomRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.EXPLOSIVE_PHANTOM.get(), ExplosivePhantomRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.VEHICLE_PHANTOM.get(), VehiclePhantomRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.PHANTOM_TAMER.get(), PhantomTamerRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.INSOMNIA_LUMP.get(), InsomniaLumpRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.ZOMBIE_EVOKER.get(), ZombieEvokerRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.ZOMBIE_RAVAGER.get(), ZombieRavagerRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.CREEPIG.get(), CreepigRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.CREEPER_GOLEM.get(), CreeperGolemRenderer::new);
		event.registerEntityRenderer(WorkspaceModEntities.EXPLOSIVE_EARTH_QUAKE.get(), ThrownItemRenderer::new);
	}
}
