
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.workspace.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.workspace.entity.ZombiefiedChadVillagerEntity;
import net.mcreator.workspace.entity.ZombieVindicatorEntity;
import net.mcreator.workspace.entity.ZombieRavagerEntity;
import net.mcreator.workspace.entity.ZombiePillagerEntity;
import net.mcreator.workspace.entity.ZombiePigEntity;
import net.mcreator.workspace.entity.ZombieEvokerEntity;
import net.mcreator.workspace.entity.ZombieCowEntity;
import net.mcreator.workspace.entity.VehiclePhantomEntity;
import net.mcreator.workspace.entity.TamedPhantomEntity;
import net.mcreator.workspace.entity.TRabusEntity;
import net.mcreator.workspace.entity.RedstonePoweredIronGolemEntity;
import net.mcreator.workspace.entity.RedstoneBombEntity;
import net.mcreator.workspace.entity.RavagerEndermanEntity;
import net.mcreator.workspace.entity.PigBruteEntity;
import net.mcreator.workspace.entity.PhantomTamerEntity;
import net.mcreator.workspace.entity.PavagerEntity;
import net.mcreator.workspace.entity.MinionRedstoneGolemEntity;
import net.mcreator.workspace.entity.InsomniaLumpEntity;
import net.mcreator.workspace.entity.HardenedSnowBallEntity;
import net.mcreator.workspace.entity.ExplosivePhantomEntity;
import net.mcreator.workspace.entity.ExplosiveEarthQuakeEntity;
import net.mcreator.workspace.entity.EnderRavagerEntity;
import net.mcreator.workspace.entity.EliteEnderRavagerEntity;
import net.mcreator.workspace.entity.EarthQuakeEntity;
import net.mcreator.workspace.entity.DerpigEntity;
import net.mcreator.workspace.entity.CyborgVindicatorEntity;
import net.mcreator.workspace.entity.CrudeRedstoneMonstrosityEntity;
import net.mcreator.workspace.entity.CrudeRedstoneGolemEntity;
import net.mcreator.workspace.entity.CreepigEntity;
import net.mcreator.workspace.entity.CreeperGolemEntity;
import net.mcreator.workspace.entity.ChadVillagerEntity;
import net.mcreator.workspace.entity.BigSnowGolemEntity;
import net.mcreator.workspace.entity.BigSnowBallEntity;
import net.mcreator.workspace.WorkspaceMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class WorkspaceModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITIES, WorkspaceMod.MODID);
	public static final RegistryObject<EntityType<ChadVillagerEntity>> CHAD_VILLAGER = register("chad_villager",
			EntityType.Builder.<ChadVillagerEntity>of(ChadVillagerEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(ChadVillagerEntity::new)

					.sized(1.4f, 2.7f));
	public static final RegistryObject<EntityType<PavagerEntity>> PAVAGER = register("pavager",
			EntityType.Builder.<PavagerEntity>of(PavagerEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(PavagerEntity::new)

					.sized(2f, 2.2f));
	public static final RegistryObject<EntityType<EnderRavagerEntity>> ENDER_RAVAGER = register("ender_ravager",
			EntityType.Builder.<EnderRavagerEntity>of(EnderRavagerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(EnderRavagerEntity::new)

					.sized(2f, 2.2f));
	public static final RegistryObject<EntityType<EliteEnderRavagerEntity>> ELITE_ENDER_RAVAGER = register("elite_ender_ravager",
			EntityType.Builder.<EliteEnderRavagerEntity>of(EliteEnderRavagerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(EliteEnderRavagerEntity::new)

					.sized(2f, 2.2f));
	public static final RegistryObject<EntityType<TRabusEntity>> T_RABUS = register("t_rabus",
			EntityType.Builder.<TRabusEntity>of(TRabusEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(TRabusEntity::new).fireImmune().sized(1.4f, 1.4f));
	public static final RegistryObject<EntityType<RavagerEndermanEntity>> RAVAGER_ENDERMAN = register("ravager_enderman",
			EntityType.Builder.<RavagerEndermanEntity>of(RavagerEndermanEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(RavagerEndermanEntity::new)

					.sized(2f, 2.2f));
	public static final RegistryObject<EntityType<DerpigEntity>> DERPIG = register("derpig",
			EntityType.Builder.<DerpigEntity>of(DerpigEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(DerpigEntity::new)

					.sized(0.7f, 1.7f));
	public static final RegistryObject<EntityType<PigBruteEntity>> PIG_BRUTE = register("pig_brute",
			EntityType.Builder.<PigBruteEntity>of(PigBruteEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(PigBruteEntity::new)

					.sized(0.7f, 1.7f));
	public static final RegistryObject<EntityType<ZombieCowEntity>> ZOMBIE_COW = register("zombie_cow",
			EntityType.Builder.<ZombieCowEntity>of(ZombieCowEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(ZombieCowEntity::new)

					.sized(0.9f, 1.9f));
	public static final RegistryObject<EntityType<ZombiePigEntity>> ZOMBIE_PIG = register("zombie_pig",
			EntityType.Builder.<ZombiePigEntity>of(ZombiePigEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(ZombiePigEntity::new)

					.sized(0.7f, 1.7f));
	public static final RegistryObject<EntityType<ZombiefiedChadVillagerEntity>> ZOMBIEFIED_CHAD_VILLAGER = register("zombiefied_chad_villager",
			EntityType.Builder.<ZombiefiedChadVillagerEntity>of(ZombiefiedChadVillagerEntity::new, MobCategory.MONSTER)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)
					.setCustomClientFactory(ZombiefiedChadVillagerEntity::new)

					.sized(1.4f, 2.7f));
	public static final RegistryObject<EntityType<RedstonePoweredIronGolemEntity>> REDSTONE_POWERED_IRON_GOLEM = register(
			"redstone_powered_iron_golem",
			EntityType.Builder.<RedstonePoweredIronGolemEntity>of(RedstonePoweredIronGolemEntity::new, MobCategory.MONSTER)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)
					.setCustomClientFactory(RedstonePoweredIronGolemEntity::new).fireImmune().sized(3f, 4f));
	public static final RegistryObject<EntityType<CyborgVindicatorEntity>> CYBORG_VINDICATOR = register("cyborg_vindicator",
			EntityType.Builder.<CyborgVindicatorEntity>of(CyborgVindicatorEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(CyborgVindicatorEntity::new)

					.sized(3f, 4f));
	public static final RegistryObject<EntityType<CrudeRedstoneGolemEntity>> CRUDE_REDSTONE_GOLEM = register("crude_redstone_golem",
			EntityType.Builder.<CrudeRedstoneGolemEntity>of(CrudeRedstoneGolemEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(CrudeRedstoneGolemEntity::new)

					.sized(1.5f, 3f));
	public static final RegistryObject<EntityType<CrudeRedstoneMonstrosityEntity>> CRUDE_REDSTONE_MONSTROSITY = register("crude_redstone_monstrosity",
			EntityType.Builder.<CrudeRedstoneMonstrosityEntity>of(CrudeRedstoneMonstrosityEntity::new, MobCategory.MONSTER)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)
					.setCustomClientFactory(CrudeRedstoneMonstrosityEntity::new)

					.sized(1.5f, 3f));
	public static final RegistryObject<EntityType<MinionRedstoneGolemEntity>> MINION_REDSTONE_GOLEM = register("minion_redstone_golem",
			EntityType.Builder.<MinionRedstoneGolemEntity>of(MinionRedstoneGolemEntity::new, MobCategory.MONSTER)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)
					.setCustomClientFactory(MinionRedstoneGolemEntity::new)

					.sized(1.5f, 3f));
	public static final RegistryObject<EntityType<RedstoneBombEntity>> REDSTONE_BOMB = register("projectile_redstone_bomb",
			EntityType.Builder.<RedstoneBombEntity>of(RedstoneBombEntity::new, MobCategory.MISC).setCustomClientFactory(RedstoneBombEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<BigSnowGolemEntity>> BIG_SNOW_GOLEM = register("big_snow_golem",
			EntityType.Builder.<BigSnowGolemEntity>of(BigSnowGolemEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(BigSnowGolemEntity::new)

					.sized(3f, 4f));
	public static final RegistryObject<EntityType<BigSnowBallEntity>> BIG_SNOW_BALL = register("projectile_big_snow_ball",
			EntityType.Builder.<BigSnowBallEntity>of(BigSnowBallEntity::new, MobCategory.MISC).setCustomClientFactory(BigSnowBallEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<HardenedSnowBallEntity>> HARDENED_SNOW_BALL = register("projectile_hardened_snow_ball",
			EntityType.Builder.<HardenedSnowBallEntity>of(HardenedSnowBallEntity::new, MobCategory.MISC)
					.setCustomClientFactory(HardenedSnowBallEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<EarthQuakeEntity>> EARTH_QUAKE = register("projectile_earth_quake",
			EntityType.Builder.<EarthQuakeEntity>of(EarthQuakeEntity::new, MobCategory.MISC).setCustomClientFactory(EarthQuakeEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<ZombieVindicatorEntity>> ZOMBIE_VINDICATOR = register("zombie_vindicator",
			EntityType.Builder.<ZombieVindicatorEntity>of(ZombieVindicatorEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(ZombieVindicatorEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<ZombiePillagerEntity>> ZOMBIE_PILLAGER = register("zombie_pillager",
			EntityType.Builder.<ZombiePillagerEntity>of(ZombiePillagerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(ZombiePillagerEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<TamedPhantomEntity>> TAMED_PHANTOM = register("tamed_phantom",
			EntityType.Builder.<TamedPhantomEntity>of(TamedPhantomEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(TamedPhantomEntity::new)

					.sized(0.9f, 0.5f));
	public static final RegistryObject<EntityType<ExplosivePhantomEntity>> EXPLOSIVE_PHANTOM = register("explosive_phantom",
			EntityType.Builder.<ExplosivePhantomEntity>of(ExplosivePhantomEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(ExplosivePhantomEntity::new)

					.sized(0.9f, 0.5f));
	public static final RegistryObject<EntityType<VehiclePhantomEntity>> VEHICLE_PHANTOM = register("vehicle_phantom",
			EntityType.Builder.<VehiclePhantomEntity>of(VehiclePhantomEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(VehiclePhantomEntity::new)

					.sized(0.9f, 0.5f));
	public static final RegistryObject<EntityType<PhantomTamerEntity>> PHANTOM_TAMER = register("phantom_tamer",
			EntityType.Builder.<PhantomTamerEntity>of(PhantomTamerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(PhantomTamerEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<InsomniaLumpEntity>> INSOMNIA_LUMP = register("projectile_insomnia_lump",
			EntityType.Builder.<InsomniaLumpEntity>of(InsomniaLumpEntity::new, MobCategory.MISC).setCustomClientFactory(InsomniaLumpEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<ZombieEvokerEntity>> ZOMBIE_EVOKER = register("zombie_evoker",
			EntityType.Builder.<ZombieEvokerEntity>of(ZombieEvokerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(ZombieEvokerEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<ZombieRavagerEntity>> ZOMBIE_RAVAGER = register("zombie_ravager",
			EntityType.Builder.<ZombieRavagerEntity>of(ZombieRavagerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(ZombieRavagerEntity::new)

					.sized(1.95f, 2.2f));
	public static final RegistryObject<EntityType<CreepigEntity>> CREEPIG = register("creepig",
			EntityType.Builder.<CreepigEntity>of(CreepigEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(CreepigEntity::new)

					.sized(0.9f, 0.9f));
	public static final RegistryObject<EntityType<CreeperGolemEntity>> CREEPER_GOLEM = register("creeper_golem",
			EntityType.Builder.<CreeperGolemEntity>of(CreeperGolemEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(CreeperGolemEntity::new)

					.sized(1.4f, 2.7f));
	public static final RegistryObject<EntityType<ExplosiveEarthQuakeEntity>> EXPLOSIVE_EARTH_QUAKE = register("projectile_explosive_earth_quake",
			EntityType.Builder.<ExplosiveEarthQuakeEntity>of(ExplosiveEarthQuakeEntity::new, MobCategory.MISC)
					.setCustomClientFactory(ExplosiveEarthQuakeEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(1).sized(0.5f, 0.5f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			ChadVillagerEntity.init();
			PavagerEntity.init();
			EnderRavagerEntity.init();
			EliteEnderRavagerEntity.init();
			TRabusEntity.init();
			RavagerEndermanEntity.init();
			DerpigEntity.init();
			PigBruteEntity.init();
			ZombieCowEntity.init();
			ZombiePigEntity.init();
			ZombiefiedChadVillagerEntity.init();
			RedstonePoweredIronGolemEntity.init();
			CyborgVindicatorEntity.init();
			CrudeRedstoneGolemEntity.init();
			CrudeRedstoneMonstrosityEntity.init();
			MinionRedstoneGolemEntity.init();
			BigSnowGolemEntity.init();
			ZombieVindicatorEntity.init();
			ZombiePillagerEntity.init();
			TamedPhantomEntity.init();
			ExplosivePhantomEntity.init();
			VehiclePhantomEntity.init();
			PhantomTamerEntity.init();
			ZombieEvokerEntity.init();
			ZombieRavagerEntity.init();
			CreepigEntity.init();
			CreeperGolemEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(CHAD_VILLAGER.get(), ChadVillagerEntity.createAttributes().build());
		event.put(PAVAGER.get(), PavagerEntity.createAttributes().build());
		event.put(ENDER_RAVAGER.get(), EnderRavagerEntity.createAttributes().build());
		event.put(ELITE_ENDER_RAVAGER.get(), EliteEnderRavagerEntity.createAttributes().build());
		event.put(T_RABUS.get(), TRabusEntity.createAttributes().build());
		event.put(RAVAGER_ENDERMAN.get(), RavagerEndermanEntity.createAttributes().build());
		event.put(DERPIG.get(), DerpigEntity.createAttributes().build());
		event.put(PIG_BRUTE.get(), PigBruteEntity.createAttributes().build());
		event.put(ZOMBIE_COW.get(), ZombieCowEntity.createAttributes().build());
		event.put(ZOMBIE_PIG.get(), ZombiePigEntity.createAttributes().build());
		event.put(ZOMBIEFIED_CHAD_VILLAGER.get(), ZombiefiedChadVillagerEntity.createAttributes().build());
		event.put(REDSTONE_POWERED_IRON_GOLEM.get(), RedstonePoweredIronGolemEntity.createAttributes().build());
		event.put(CYBORG_VINDICATOR.get(), CyborgVindicatorEntity.createAttributes().build());
		event.put(CRUDE_REDSTONE_GOLEM.get(), CrudeRedstoneGolemEntity.createAttributes().build());
		event.put(CRUDE_REDSTONE_MONSTROSITY.get(), CrudeRedstoneMonstrosityEntity.createAttributes().build());
		event.put(MINION_REDSTONE_GOLEM.get(), MinionRedstoneGolemEntity.createAttributes().build());
		event.put(BIG_SNOW_GOLEM.get(), BigSnowGolemEntity.createAttributes().build());
		event.put(ZOMBIE_VINDICATOR.get(), ZombieVindicatorEntity.createAttributes().build());
		event.put(ZOMBIE_PILLAGER.get(), ZombiePillagerEntity.createAttributes().build());
		event.put(TAMED_PHANTOM.get(), TamedPhantomEntity.createAttributes().build());
		event.put(EXPLOSIVE_PHANTOM.get(), ExplosivePhantomEntity.createAttributes().build());
		event.put(VEHICLE_PHANTOM.get(), VehiclePhantomEntity.createAttributes().build());
		event.put(PHANTOM_TAMER.get(), PhantomTamerEntity.createAttributes().build());
		event.put(ZOMBIE_EVOKER.get(), ZombieEvokerEntity.createAttributes().build());
		event.put(ZOMBIE_RAVAGER.get(), ZombieRavagerEntity.createAttributes().build());
		event.put(CREEPIG.get(), CreepigEntity.createAttributes().build());
		event.put(CREEPER_GOLEM.get(), CreeperGolemEntity.createAttributes().build());
	}
}
