
package net.mcreator.workspace.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.workspace.entity.CrudeRedstoneGolemEntity;
import net.mcreator.workspace.GolemAnimatedWardenRenderer;
import net.mcreator.workspace.GolemAnimatedWarden;

public class CrudeRedstoneGolemRenderer extends GolemAnimatedWardenRenderer<CrudeRedstoneGolemEntity, GolemAnimatedWarden<CrudeRedstoneGolemEntity>> {
	public CrudeRedstoneGolemRenderer(EntityRendererProvider.Context context) {
		super(context, new GolemAnimatedWarden(context.bakeLayer(GolemAnimatedWarden.LAYER_LOCATION)), 1f);
	}

	@Override
	public ResourceLocation getTextureLocation(CrudeRedstoneGolemEntity entity) {
		return new ResourceLocation("workspace:textures/redstone-golem-on-planetminecraft-com.png");
	}
}
