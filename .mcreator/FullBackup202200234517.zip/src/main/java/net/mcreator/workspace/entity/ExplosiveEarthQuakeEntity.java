
package net.mcreator.workspace.entity;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.network.PlayMessages;
import net.minecraftforge.network.NetworkHooks;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.util.Mth;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.protocol.Packet;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import net.mcreator.workspace.init.WorkspaceModEntities;
import net.mcreator.workspace.CustomMathHelper;

import java.util.Random;

public class ExplosiveEarthQuakeEntity extends ThrowableItemProjectile {
	public float size = 2;
	public short shockRange = 10;
	public float damage = 5;
	public short shockSpeed = 5;
	public short yaw = 0;
	private Vec3 lookVec = this.getLookAngle();

	public void addAdditionalSaveData(CompoundTag p_32304_) {
		super.addAdditionalSaveData(p_32304_);
		p_32304_.putShort("shockRange", this.shockRange);
		//p_32304_.putShort("lifeTime", this.lifeTime);
		p_32304_.putShort("shockSpeed", this.shockSpeed);
		p_32304_.putShort("yaw", this.yaw);
		p_32304_.putFloat("damage", this.damage);
		p_32304_.putFloat("size", this.size);
	}

	public void readAdditionalSaveData(CompoundTag p_32296_) {
		super.readAdditionalSaveData(p_32296_);
		this.shockRange = p_32296_.getShort("shockRange");
		//this.lifeTime = p_32296_.getShort("lifeTime");
		this.shockSpeed = p_32296_.getShort("shockSpeed");
		this.yaw = p_32296_.getShort("yaw");
		this.damage = p_32296_.getFloat("damage");
		this.size = p_32296_.getFloat("size");
		this.lookVec = this.calculateViewVector(0, this.yaw);
	}

	public ExplosiveEarthQuakeEntity(PlayMessages.SpawnEntity packet, Level world) {
		super(WorkspaceModEntities.EXPLOSIVE_EARTH_QUAKE.get(), world);
	}

	public ExplosiveEarthQuakeEntity(EntityType<? extends EarthQuakeEntity> type, Level world) {
		super(type, world);
		//this.setInvisible(true);
		//this.refreshDimensions();
	}

	public ExplosiveEarthQuakeEntity(Level p_37399_, LivingEntity p_37400_) {
		super(WorkspaceModEntities.EXPLOSIVE_EARTH_QUAKE.get(), p_37400_, p_37399_);
	}

	public ExplosiveEarthQuakeEntity(Level p_37394_, double p_37395_, double p_37396_, double p_37397_) {
		super(WorkspaceModEntities.EXPLOSIVE_EARTH_QUAKE.get(), p_37395_, p_37396_, p_37397_, p_37394_);
	}

	public boolean isPickable() {
		return false;
	}

	public boolean isOnFire() {
		return false;
	}

	@Override
	public Packet<?> getAddEntityPacket() {
		return NetworkHooks.getEntitySpawningPacket(this);
	}

	public boolean isNoGravity() {
		return true;
	}

	protected Item getDefaultItem() {
		return Items.AIR;
	}

	protected BlockPos getNextPosition() {
		return new BlockPos(this.getX() + this.lookVec.x * size / 2, this.getY(), this.getZ() + this.lookVec.z * size / 2);
	}

	@Override
	public void tick() {
		super.tick();
		if (!this.level.isClientSide)
			if (this.tickCount % this.shockSpeed == 0) {
				this.lookVec = this.calculateViewVector(0, this.yaw);
				//this.moveTo(this.getX() + this.getLookAngle().x * size / 2, this.getY(), this.getZ() + this.getLookAngle().z * size / 2);
				BlockPos blockpos = this.getNextPosition();
				boolean flag = false;
				double d0 = 0.0D;
				do {
					BlockPos blockpos1 = blockpos.below();
					BlockState blockstate = this.level.getBlockState(blockpos1);
					if (blockstate.isFaceSturdy(this.level, blockpos1, Direction.UP)) {
						if (!this.level.isEmptyBlock(blockpos)) {
							BlockState blockstate1 = this.level.getBlockState(blockpos);
							VoxelShape voxelshape = blockstate1.getCollisionShape(this.level, blockpos);
							if (!voxelshape.isEmpty()) {
								d0 = voxelshape.max(Direction.Axis.Y);
							}
						}
						flag = true;
						break;
					}
					blockpos = blockpos.below();
				} while (blockpos.getY() >= Mth.floor(this.getY()) - 3);
				if (flag) {
					this.setPos(this.getX() + this.lookVec.x * size / 2, blockpos.getY() + d0, this.getZ() + this.lookVec.z * size / 2);
					AABB attackRange = CustomMathHelper.makeAttackRange(this.getX(), this.getY(), this.getZ(), 0, size, 0.6, size);
					for (LivingEntity livingentity : this.level.getEntitiesOfClass(LivingEntity.class, attackRange)) {
						Entity owner = this.getOwner();
						if (owner == null) {
							if (livingentity.hurt(DamageSource.indirectMobAttack(this, null), this.damage)) {
								this.strongKnockback(livingentity, 0.5);
							}
						} else {
							if (livingentity != owner)
								if (!livingentity.isAlliedTo(owner)
										&& livingentity.hurt(DamageSource.indirectMobAttack(this, (LivingEntity) this.getOwner()), this.damage)) {
									this.strongKnockback(livingentity, 0.5);
								}
						}
					}
				} else {
					this.discard();
				}
				/*
				BlockState blockstate = this.level.getBlockState(blockpos);
				if (!blockstate.isAir()) {
					for (int i = 0; i < 10 * size; i++)
						this.level.addParticle(new BlockParticleOption(ParticleTypes.BLOCK, blockstate).setPos(blockpos),
								this.getX() + ((double) this.random.nextFloat() - 0.5D) * (double) size, this.getY(),
								this.getZ() + ((double) this.random.nextFloat() - 0.5D) * (double) size, 4.0D * ((double) this.random.nextFloat() - 0.5D),
								0.5D, ((double) this.random.nextFloat() - 0.5D) * 4.0D);
				}
				*/
				if (this.shockRange > 0)
					this.shockRange--;
				else
					this.discard();
			}
	}

	public static ExplosiveEarthQuakeEntity shoot(Level world, LivingEntity entity, Random random, float power, double damage, int knockback) {
		ExplosiveEarthQuakeEntity entityarrow = new ExplosiveEarthQuakeEntity(WorkspaceModEntities.EXPLOSIVE_EARTH_QUAKE.get(), entity, world);
		entityarrow.shoot(entity.getViewVector(1).x, entity.getViewVector(1).y, entity.getViewVector(1).z, power * 2, 0);
		entityarrow.setSilent(true);
		entityarrow.setCritArrow(false);
		entityarrow.setBaseDamage(damage);
		entityarrow.setKnockback(knockback);
		world.addFreshEntity(entityarrow);
		world.playSound(null, entity.getX(), entity.getY(), entity.getZ(), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("")),
				SoundSource.PLAYERS, 1, 1f / (random.nextFloat() * 0.5f + 1) + (power / 2));
		return entityarrow;
	}

	public static ExplosiveEarthQuakeEntity shoot(LivingEntity entity, LivingEntity target) {
		ExplosiveEarthQuakeEntity entityarrow = new ExplosiveEarthQuakeEntity(WorkspaceModEntities.EXPLOSIVE_EARTH_QUAKE.get(), entity, entity.level);
		double dx = target.getX() - entity.getX();
		double dy = target.getY() + target.getEyeHeight() - 1.1;
		double dz = target.getZ() - entity.getZ();
		entityarrow.shoot(dx, dy - entityarrow.getY() + Math.hypot(dx, dz) * 0.2F, dz, 1f * 2, 12.0F);
		entityarrow.setSilent(true);
		entityarrow.setBaseDamage(5);
		entityarrow.setKnockback(5);
		entityarrow.setCritArrow(false);
		entity.level.addFreshEntity(entityarrow);
		entity.level.playSound(null, entity.getX(), entity.getY(), entity.getZ(), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("")),
				SoundSource.PLAYERS, 1, 1f / (new Random().nextFloat() * 0.5f + 1));
		return entityarrow;
	}
}
