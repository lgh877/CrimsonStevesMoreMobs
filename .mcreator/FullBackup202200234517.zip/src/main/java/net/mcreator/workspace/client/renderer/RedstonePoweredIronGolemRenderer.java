
package net.mcreator.workspace.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;

import net.mcreator.workspace.entity.RedstonePoweredIronGolemEntity;
import net.mcreator.workspace.AnimatedRedstoneGolemRenderer;
import net.mcreator.workspace.AnimatedRedstoneGolemModel;

public class RedstonePoweredIronGolemRenderer
		extends
			AnimatedRedstoneGolemRenderer<RedstonePoweredIronGolemEntity, AnimatedRedstoneGolemModel<RedstonePoweredIronGolemEntity>> {
	public RedstonePoweredIronGolemRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedRedstoneGolemModel(context.bakeLayer(AnimatedRedstoneGolemModel.LAYER_LOCATION)), 1.1f);
		this.addLayer(new EyesLayer<RedstonePoweredIronGolemEntity, AnimatedRedstoneGolemModel<RedstonePoweredIronGolemEntity>>(this) {
			@Override
			public RenderType renderType() {
				return RenderType.eyes(new ResourceLocation("workspace:textures/redstone_powered_golem_eyes.png"));
			}
		});
	}

	@Override
	public ResourceLocation getTextureLocation(RedstonePoweredIronGolemEntity entity) {
		return new ResourceLocation("workspace:textures/redstone_powered_iron_golem.png");
	}
}
