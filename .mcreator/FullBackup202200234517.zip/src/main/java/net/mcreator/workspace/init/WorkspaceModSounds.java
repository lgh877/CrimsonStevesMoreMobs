
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.workspace.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import java.util.Map;
import java.util.HashMap;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class WorkspaceModSounds {
	public static Map<ResourceLocation, SoundEvent> REGISTRY = new HashMap<>();
	static {
		REGISTRY.put(new ResourceLocation("workspace", "redstonegolem_hit"), new SoundEvent(new ResourceLocation("workspace", "redstonegolem_hit")));
		REGISTRY.put(new ResourceLocation("workspace", "redstonegolem_death"),
				new SoundEvent(new ResourceLocation("workspace", "redstonegolem_death")));
		REGISTRY.put(new ResourceLocation("workspace", "redstonegolem_idle"),
				new SoundEvent(new ResourceLocation("workspace", "redstonegolem_idle")));
		REGISTRY.put(new ResourceLocation("workspace", "redstonegolem_growl"),
				new SoundEvent(new ResourceLocation("workspace", "redstonegolem_growl")));
		REGISTRY.put(new ResourceLocation("workspace", "redstonegolem_electric"),
				new SoundEvent(new ResourceLocation("workspace", "redstonegolem_electric")));
		REGISTRY.put(new ResourceLocation("workspace", "redstonegolem_step"),
				new SoundEvent(new ResourceLocation("workspace", "redstonegolem_step")));
		REGISTRY.put(new ResourceLocation("workspace", "endersent_hurt"), new SoundEvent(new ResourceLocation("workspace", "endersent_hurt")));
		REGISTRY.put(new ResourceLocation("workspace", "endersent_death"), new SoundEvent(new ResourceLocation("workspace", "endersent_death")));
		REGISTRY.put(new ResourceLocation("workspace", "endersent_idle"), new SoundEvent(new ResourceLocation("workspace", "endersent_idle")));
		REGISTRY.put(new ResourceLocation("workspace", "endersent_step"), new SoundEvent(new ResourceLocation("workspace", "endersent_step")));
		REGISTRY.put(new ResourceLocation("workspace", "robot_idle"), new SoundEvent(new ResourceLocation("workspace", "robot_idle")));
		REGISTRY.put(new ResourceLocation("workspace", "monstrosity_idle"), new SoundEvent(new ResourceLocation("workspace", "monstrosity_idle")));
		REGISTRY.put(new ResourceLocation("workspace", "monstrosity_shoot"), new SoundEvent(new ResourceLocation("workspace", "monstrosity_shoot")));
		REGISTRY.put(new ResourceLocation("workspace", "monstrosity_death"), new SoundEvent(new ResourceLocation("workspace", "monstrosity_death")));
		REGISTRY.put(new ResourceLocation("workspace", "monstrosity_hurt"), new SoundEvent(new ResourceLocation("workspace", "monstrosity_hurt")));
		REGISTRY.put(new ResourceLocation("workspace", "monstrosity_step"), new SoundEvent(new ResourceLocation("workspace", "monstrosity_step")));
	}

	@SubscribeEvent
	public static void registerSounds(RegistryEvent.Register<SoundEvent> event) {
		for (Map.Entry<ResourceLocation, SoundEvent> sound : REGISTRY.entrySet())
			event.getRegistry().register(sound.getValue().setRegistryName(sound.getKey()));
	}
}
