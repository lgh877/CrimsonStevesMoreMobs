
package net.mcreator.workspace.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.workspace.entity.PigBruteEntity;
import net.mcreator.workspace.client.model.ModelAnimatedWardenPigModel;

public class PigBruteRenderer extends MobRenderer<PigBruteEntity, ModelAnimatedWardenPigModel<PigBruteEntity>> {
	public PigBruteRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelAnimatedWardenPigModel(context.bakeLayer(ModelAnimatedWardenPigModel.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(PigBruteEntity entity) {
		return new ResourceLocation("workspace:textures/entities/pig-brute-on-planetminecraft-com.png");
	}
}
