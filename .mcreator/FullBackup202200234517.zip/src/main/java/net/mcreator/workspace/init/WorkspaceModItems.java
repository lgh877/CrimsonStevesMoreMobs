
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.workspace.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.item.Item;

import net.mcreator.workspace.item.RedstoneBombItem;
import net.mcreator.workspace.item.InsomniaLumpItem;
import net.mcreator.workspace.item.HardenedSnowBallItem;
import net.mcreator.workspace.item.ExplosiveEarthQuakeItem;
import net.mcreator.workspace.item.EarthQuakeItem;
import net.mcreator.workspace.item.BigSnowBallItem;
import net.mcreator.workspace.WorkspaceMod;

public class WorkspaceModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, WorkspaceMod.MODID);
	public static final RegistryObject<Item> CHAD_VILLAGER = REGISTRY.register("chad_villager_spawn_egg",
			() -> new ForgeSpawnEggItem(WorkspaceModEntities.CHAD_VILLAGER, -8628136, -7576219,
					new Item.Properties().tab(WorkspaceModTabs.TAB_OTHERS_TAB)));
	public static final RegistryObject<Item> PAVAGER = REGISTRY.register("pavager_spawn_egg",
			() -> new ForgeSpawnEggItem(WorkspaceModEntities.PAVAGER, -5211269, -606530, new Item.Properties().tab(WorkspaceModTabs.TAB_OTHERS_TAB)));
	public static final RegistryObject<Item> ENDER_RAVAGER = REGISTRY.register("ender_ravager_spawn_egg",
			() -> new ForgeSpawnEggItem(WorkspaceModEntities.ENDER_RAVAGER, -13893588, -14809039,
					new Item.Properties().tab(WorkspaceModTabs.TAB_MONSTERS_TAB)));
	public static final RegistryObject<Item> ELITE_ENDER_RAVAGER = REGISTRY.register("elite_ender_ravager_spawn_egg",
			() -> new ForgeSpawnEggItem(WorkspaceModEntities.ELITE_ENDER_RAVAGER, -4565534, -3497510,
					new Item.Properties().tab(WorkspaceModTabs.TAB_MONSTERS_TAB)));
	public static final RegistryObject<Item> T_RABUS = REGISTRY.register("t_rabus_spawn_egg",
			() -> new ForgeSpawnEggItem(WorkspaceModEntities.T_RABUS, -10066330, -65536,
					new Item.Properties().tab(WorkspaceModTabs.TAB_ILLAGERS_TAB)));
	public static final RegistryObject<Item> RAVAGER_ENDERMAN = REGISTRY.register("ravager_enderman_spawn_egg",
			() -> new ForgeSpawnEggItem(WorkspaceModEntities.RAVAGER_ENDERMAN, -14935012, -13620173,
					new Item.Properties().tab(WorkspaceModTabs.TAB_MONSTERS_TAB)));
	public static final RegistryObject<Item> DERPIG = REGISTRY.register("derpig_spawn_egg",
			() -> new ForgeSpawnEggItem(WorkspaceModEntities.DERPIG, -26215, -39322, new Item.Properties().tab(WorkspaceModTabs.TAB_MONSTERS_TAB)));
	public static final RegistryObject<Item> PIG_BRUTE = REGISTRY.register("pig_brute_spawn_egg",
			() -> new ForgeSpawnEggItem(WorkspaceModEntities.PIG_BRUTE, -26215, -10079488,
					new Item.Properties().tab(WorkspaceModTabs.TAB_MONSTERS_TAB)));
	public static final RegistryObject<Item> ZOMBIE_COW = REGISTRY.register("zombie_cow_spawn_egg",
			() -> new ForgeSpawnEggItem(WorkspaceModEntities.ZOMBIE_COW, -10092442, -13434880,
					new Item.Properties().tab(WorkspaceModTabs.TAB_MONSTERS_TAB)));
	public static final RegistryObject<Item> ZOMBIE_PIG = REGISTRY.register("zombie_pig_spawn_egg",
			() -> new ForgeSpawnEggItem(WorkspaceModEntities.ZOMBIE_PIG, -26215, -16764160,
					new Item.Properties().tab(WorkspaceModTabs.TAB_MONSTERS_TAB)));
	public static final RegistryObject<Item> ZOMBIEFIED_CHAD_VILLAGER = REGISTRY.register("zombiefied_chad_villager_spawn_egg",
			() -> new ForgeSpawnEggItem(WorkspaceModEntities.ZOMBIEFIED_CHAD_VILLAGER, -16751053, -11189437,
					new Item.Properties().tab(WorkspaceModTabs.TAB_MONSTERS_TAB)));
	public static final RegistryObject<Item> REDSTONE_POWERED_IRON_GOLEM = REGISTRY.register("redstone_powered_iron_golem_spawn_egg",
			() -> new ForgeSpawnEggItem(WorkspaceModEntities.REDSTONE_POWERED_IRON_GOLEM, -3355444, -1,
					new Item.Properties().tab(WorkspaceModTabs.TAB_OTHERS_TAB)));
	public static final RegistryObject<Item> CYBORG_VINDICATOR = REGISTRY.register("cyborg_vindicator_spawn_egg",
			() -> new ForgeSpawnEggItem(WorkspaceModEntities.CYBORG_VINDICATOR, -10066330, -13421773,
					new Item.Properties().tab(WorkspaceModTabs.TAB_ILLAGERS_TAB)));
	public static final RegistryObject<Item> CRUDE_REDSTONE_GOLEM = REGISTRY.register("crude_redstone_golem_spawn_egg",
			() -> new ForgeSpawnEggItem(WorkspaceModEntities.CRUDE_REDSTONE_GOLEM, -10092544, -14672611,
					new Item.Properties().tab(WorkspaceModTabs.TAB_ILLAGERS_TAB)));
	public static final RegistryObject<Item> CRUDE_REDSTONE_MONSTROSITY = REGISTRY.register("crude_redstone_monstrosity_spawn_egg",
			() -> new ForgeSpawnEggItem(WorkspaceModEntities.CRUDE_REDSTONE_MONSTROSITY, -14483456, -16777216,
					new Item.Properties().tab(WorkspaceModTabs.TAB_ILLAGERS_TAB)));
	public static final RegistryObject<Item> MINION_REDSTONE_GOLEM = REGISTRY.register("minion_redstone_golem_spawn_egg",
			() -> new ForgeSpawnEggItem(WorkspaceModEntities.MINION_REDSTONE_GOLEM, -13434880, -13434880,
					new Item.Properties().tab(WorkspaceModTabs.TAB_ILLAGERS_TAB)));
	public static final RegistryObject<Item> REDSTONE_BOMB = REGISTRY.register("redstone_bomb", () -> new RedstoneBombItem());
	public static final RegistryObject<Item> BIG_SNOW_GOLEM = REGISTRY.register("big_snow_golem_spawn_egg",
			() -> new ForgeSpawnEggItem(WorkspaceModEntities.BIG_SNOW_GOLEM, -1, -1, new Item.Properties().tab(WorkspaceModTabs.TAB_OTHERS_TAB)));
	public static final RegistryObject<Item> BIG_SNOW_BALL = REGISTRY.register("big_snow_ball", () -> new BigSnowBallItem());
	public static final RegistryObject<Item> HARDENED_SNOW_BALL = REGISTRY.register("hardened_snow_ball", () -> new HardenedSnowBallItem());
	public static final RegistryObject<Item> EARTH_QUAKE = REGISTRY.register("earth_quake", () -> new EarthQuakeItem());
	public static final RegistryObject<Item> ZOMBIE_VINDICATOR = REGISTRY.register("zombie_vindicator_spawn_egg",
			() -> new ForgeSpawnEggItem(WorkspaceModEntities.ZOMBIE_VINDICATOR, -16751002, -13421773,
					new Item.Properties().tab(WorkspaceModTabs.TAB_MONSTERS_TAB)));
	public static final RegistryObject<Item> ZOMBIE_PILLAGER = REGISTRY.register("zombie_pillager_spawn_egg",
			() -> new ForgeSpawnEggItem(WorkspaceModEntities.ZOMBIE_PILLAGER, -16751053, -13421773,
					new Item.Properties().tab(WorkspaceModTabs.TAB_MONSTERS_TAB)));
	public static final RegistryObject<Item> TAMED_PHANTOM = REGISTRY.register("tamed_phantom_spawn_egg",
			() -> new ForgeSpawnEggItem(WorkspaceModEntities.TAMED_PHANTOM, -10066330, -16777165,
					new Item.Properties().tab(WorkspaceModTabs.TAB_ILLAGERS_TAB)));
	public static final RegistryObject<Item> EXPLOSIVE_PHANTOM = REGISTRY.register("explosive_phantom_spawn_egg",
			() -> new ForgeSpawnEggItem(WorkspaceModEntities.EXPLOSIVE_PHANTOM, -10066330, -6737152,
					new Item.Properties().tab(WorkspaceModTabs.TAB_ILLAGERS_TAB)));
	public static final RegistryObject<Item> VEHICLE_PHANTOM = REGISTRY.register("vehicle_phantom_spawn_egg",
			() -> new ForgeSpawnEggItem(WorkspaceModEntities.VEHICLE_PHANTOM, -13421773, -16777114,
					new Item.Properties().tab(WorkspaceModTabs.TAB_ILLAGERS_TAB)));
	public static final RegistryObject<Item> PHANTOM_TAMER = REGISTRY.register("phantom_tamer_spawn_egg",
			() -> new ForgeSpawnEggItem(WorkspaceModEntities.PHANTOM_TAMER, -10066330, -13421569,
					new Item.Properties().tab(WorkspaceModTabs.TAB_ILLAGERS_TAB)));
	public static final RegistryObject<Item> INSOMNIA_LUMP = REGISTRY.register("insomnia_lump", () -> new InsomniaLumpItem());
	public static final RegistryObject<Item> ZOMBIE_EVOKER = REGISTRY.register("zombie_evoker_spawn_egg",
			() -> new ForgeSpawnEggItem(WorkspaceModEntities.ZOMBIE_EVOKER, -16764109, -10066330,
					new Item.Properties().tab(WorkspaceModTabs.TAB_MONSTERS_TAB)));
	public static final RegistryObject<Item> ZOMBIE_RAVAGER = REGISTRY.register("zombie_ravager_spawn_egg",
			() -> new ForgeSpawnEggItem(WorkspaceModEntities.ZOMBIE_RAVAGER, -13421773, -16764109,
					new Item.Properties().tab(WorkspaceModTabs.TAB_MONSTERS_TAB)));
	public static final RegistryObject<Item> CREEPIG = REGISTRY.register("creepig_spawn_egg",
			() -> new ForgeSpawnEggItem(WorkspaceModEntities.CREEPIG, -16737997, -8211943,
					new Item.Properties().tab(WorkspaceModTabs.TAB_MONSTERS_TAB)));
	public static final RegistryObject<Item> CREEPER_GOLEM = REGISTRY.register("creeper_golem_spawn_egg",
			() -> new ForgeSpawnEggItem(WorkspaceModEntities.CREEPER_GOLEM, -16751053, -16764109,
					new Item.Properties().tab(WorkspaceModTabs.TAB_OTHERS_TAB)));
	public static final RegistryObject<Item> EXPLOSIVE_EARTH_QUAKE = REGISTRY.register("explosive_earth_quake", () -> new ExplosiveEarthQuakeItem());
}
