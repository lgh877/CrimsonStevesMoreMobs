
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.workspace.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.workspace.client.model.ModelanimatedRavagerModel;
import net.mcreator.workspace.client.model.ModelCustomHoglinModel;
import net.mcreator.workspace.client.model.ModelAnimatedWardenPigModel;
import net.mcreator.workspace.client.model.ModelAnimatedWardenModel;
import net.mcreator.workspace.client.model.ModelAnimatedWardenIronGolemModel;
import net.mcreator.workspace.client.model.ModelAnimatedWardenCowModel;
import net.mcreator.workspace.client.model.ModelAnimatedStalkerModel;
import net.mcreator.workspace.client.model.ModelAnimatedRedstoneGolemModel;
import net.mcreator.workspace.client.model.ModelAnimatedIronGolemModel;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class WorkspaceModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(ModelanimatedRavagerModel.LAYER_LOCATION, ModelanimatedRavagerModel::createBodyLayer);
		event.registerLayerDefinition(ModelAnimatedIronGolemModel.LAYER_LOCATION, ModelAnimatedIronGolemModel::createBodyLayer);
		event.registerLayerDefinition(ModelAnimatedRedstoneGolemModel.LAYER_LOCATION, ModelAnimatedRedstoneGolemModel::createBodyLayer);
		event.registerLayerDefinition(ModelAnimatedStalkerModel.LAYER_LOCATION, ModelAnimatedStalkerModel::createBodyLayer);
		event.registerLayerDefinition(ModelAnimatedWardenIronGolemModel.LAYER_LOCATION, ModelAnimatedWardenIronGolemModel::createBodyLayer);
		event.registerLayerDefinition(ModelAnimatedWardenModel.LAYER_LOCATION, ModelAnimatedWardenModel::createBodyLayer);
		event.registerLayerDefinition(ModelCustomHoglinModel.LAYER_LOCATION, ModelCustomHoglinModel::createBodyLayer);
		event.registerLayerDefinition(ModelAnimatedWardenCowModel.LAYER_LOCATION, ModelAnimatedWardenCowModel::createBodyLayer);
		event.registerLayerDefinition(ModelAnimatedWardenPigModel.LAYER_LOCATION, ModelAnimatedWardenPigModel::createBodyLayer);
	}
}
