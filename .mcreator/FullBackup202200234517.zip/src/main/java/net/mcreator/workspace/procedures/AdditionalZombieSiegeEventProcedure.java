package net.mcreator.workspace.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.village.VillageSiegeEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;

import net.mcreator.workspace.init.WorkspaceModEntities;
import net.mcreator.workspace.entity.ZombiePigEntity;
import net.mcreator.workspace.entity.ZombieCowEntity;

import javax.annotation.Nullable;

import java.util.Random;

@Mod.EventBusSubscriber
public class AdditionalZombieSiegeEventProcedure {
	@SubscribeEvent
	public static void onVillageSiege(VillageSiegeEvent event) {
		execute(event, event.getWorld(), event.getAttemptedSpawnPos().x, event.getAttemptedSpawnPos().y, event.getAttemptedSpawnPos().z);
	}

	public static void execute(LevelAccessor world, double x, double y, double z) {
		execute(null, world, x, y, z);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z) {
		double mobCount = 0;
		for (int index0 = 0; index0 < (int) (Mth.nextInt(new Random(), 1, 10)); index0++) {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new ZombieCowEntity(WorkspaceModEntities.ZOMBIE_COW.get(), _level);
				entityToSpawn.moveTo(x, y, z, world.getRandom().nextFloat() * 360F, 0);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null,
							null);
				world.addFreshEntity(entityToSpawn);
			}
		}
		for (int index1 = 0; index1 < (int) (Mth.nextInt(new Random(), 1, 10)); index1++) {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new ZombiePigEntity(WorkspaceModEntities.ZOMBIE_PIG.get(), _level);
				entityToSpawn.moveTo(x, y, z, world.getRandom().nextFloat() * 360F, 0);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null,
							null);
				world.addFreshEntity(entityToSpawn);
			}
		}
	}
}
