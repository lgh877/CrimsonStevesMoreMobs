
package net.mcreator.workspace.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.workspace.entity.ZombieVindicatorEntity;
import net.mcreator.workspace.WardenAnimatedIllagerModel;

public class ZombieVindicatorRenderer extends MobRenderer<ZombieVindicatorEntity, WardenAnimatedIllagerModel<ZombieVindicatorEntity>> {
	public ZombieVindicatorRenderer(EntityRendererProvider.Context context) {
		super(context, new WardenAnimatedIllagerModel(context.bakeLayer(WardenAnimatedIllagerModel.LAYER_LOCATION)), 0.5f);
		this.addLayer(new ItemInHandLayer<>(this));
	}

	@Override
	public ResourceLocation getTextureLocation(ZombieVindicatorEntity entity) {
		return new ResourceLocation("workspace:textures/entities/zombie_vindicator.png");
	}
}
