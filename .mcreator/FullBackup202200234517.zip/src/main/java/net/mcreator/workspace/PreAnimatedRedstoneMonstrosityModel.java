/**
 * The code of this mod element is always locked.
 *
 * You can register new events in this class too.
 *
 * If you want to make a plain independent class, create it using
 * Project Browser -> New... and make sure to make the class
 * outside net.mcreator.workspace as this package is managed by MCreator.
 *
 * If you change workspace package, modid or prefix, you will need
 * to manually adapt this file to these changes or remake it.
 *
 * This class will be added in the mod root package.
*/
package net.mcreator.workspace;

import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.HierarchicalModel;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class PreAnimatedRedstoneMonstrosityModel<T extends PathfinderMob> extends HierarchicalModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("workspace", "pre_animated_redstone_monstrosity"), "main");
	protected final ModelPart root;
	protected final ModelPart lowerBody;
	protected final ModelPart upperBody;
	protected final ModelPart head;
	protected final ModelPart jaw;
	protected final ModelPart leftHorn;
	protected final ModelPart rightHorn;
	protected final ModelPart leftShoulder;
	protected final ModelPart leftWrist;
	protected final ModelPart leftHand;
	protected final ModelPart leftFinger1;
	protected final ModelPart leftFinger2;
	protected final ModelPart leftFinger3;
	protected final ModelPart rightShoulder;
	protected final ModelPart rightWrist;
	protected final ModelPart rightHand;
	protected final ModelPart rightFinger1;
	protected final ModelPart rightFinger2;
	protected final ModelPart rightFinger3;
	protected final ModelPart leftLeg;
	protected final ModelPart rightLeg;

	public PreAnimatedRedstoneMonstrosityModel(ModelPart root) {
		this.root = root;
		this.leftLeg = root.getChild("leftLeg");
		this.rightLeg = root.getChild("rightLeg");
		this.lowerBody = root.getChild("lowerBody");
		this.upperBody = lowerBody.getChild("upperBody");
		this.head = upperBody.getChild("head");
		this.jaw = head.getChild("jaw");
		this.leftHorn = head.getChild("leftHorn");
		this.rightHorn = head.getChild("rightHorn");
		this.leftShoulder = upperBody.getChild("leftShoulder");
		this.leftWrist = leftShoulder.getChild("leftWrist");
		this.leftHand = leftWrist.getChild("leftHand");
		this.leftFinger1 = leftHand.getChild("leftFinger1");
		this.leftFinger2 = leftHand.getChild("leftFinger2");
		this.leftFinger3 = leftHand.getChild("leftFinger3");
		this.rightShoulder = upperBody.getChild("rightShoulder");
		this.rightWrist = rightShoulder.getChild("rightWrist");
		this.rightHand = rightWrist.getChild("rightHand");
		this.rightFinger1 = rightHand.getChild("rightFinger1");
		this.rightFinger2 = rightHand.getChild("rightFinger2");
		this.rightFinger3 = rightHand.getChild("rightFinger3");
	}

	public ModelPart root() {
		return this.root;
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();
		PartDefinition leftLeg = partdefinition.addOrReplaceChild("leftLeg",
				CubeListBuilder.create().texOffs(197, 87).addBox(-12.0F, -2.5F, -9.5F, 24.0F, 29.0F, 19.0F, new CubeDeformation(0.0F)),
				PartPose.offset(21.0F, -2.5F, -1.5F));
		PartDefinition rightLeg = partdefinition.addOrReplaceChild(
				"rightLeg", CubeListBuilder.create().texOffs(197, 87).mirror()
						.addBox(-12.0F, -2.5F, -9.5F, 24.0F, 29.0F, 19.0F, new CubeDeformation(0.0F)).mirror(false),
				PartPose.offset(-21.0F, -2.5F, -1.5F));
		PartDefinition lowerBody = partdefinition.addOrReplaceChild("lowerBody",
				CubeListBuilder.create().texOffs(99, 52).addBox(-14.0F, -9.5F, -10.5F, 28.0F, 11.0F, 21.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, -2.75F, -1.5F));
		PartDefinition upperBody = lowerBody.addOrReplaceChild("upperBody",
				CubeListBuilder.create().texOffs(197, 0).addBox(-38.0F, -54.25F, -14.5F, 74.0F, 57.0F, 30.0F, new CubeDeformation(0.0F))
						.texOffs(375, 3).addBox(-16.0F, -48.0F, 15.0F, 28.0F, 16.0F, 11.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, -12.0F, 0.0F));
		PartDefinition head = upperBody.addOrReplaceChild("head",
				CubeListBuilder.create().texOffs(98, 0).addBox(-14.0F, -17.7917F, -11.0833F, 28.0F, 31.0F, 21.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, -30.7083F, -24.3167F));
		PartDefinition leftHorn = head.addOrReplaceChild("leftHorn",
				CubeListBuilder.create().texOffs(188, 161).addBox(0.0F, -6.5F, -6.5F, 20.0F, 13.0F, 13.0F, new CubeDeformation(0.0F))
						.texOffs(254, 163).addBox(11.0F, -21.5F, -6.5F, 9.0F, 15.0F, 13.0F, new CubeDeformation(0.0F)),
				PartPose.offset(14.0F, -6.0417F, 0.3167F));
		PartDefinition rightHorn = head.addOrReplaceChild("rightHorn",
				CubeListBuilder.create().texOffs(188, 135).addBox(-20.0F, -6.5F, -6.5F, 20.0F, 13.0F, 13.0F, new CubeDeformation(0.0F))
						.texOffs(254, 135).addBox(-20.0F, -21.5F, -6.5F, 9.0F, 15.0F, 13.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-14.0F, -6.0417F, 0.3167F));
		PartDefinition jaw = head.addOrReplaceChild("jaw",
				CubeListBuilder.create().texOffs(0, 0).addBox(-13.5F, -7.5417F, -22.1833F, 27.0F, 10.0F, 21.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 15.0F, 11.0F));
		PartDefinition leftShoulder = upperBody
				.addOrReplaceChild("leftShoulder",
						CubeListBuilder.create().texOffs(0, 134).addBox(-3.25F, -11.0F, -13.5F, 37.0F, 23.0F, 27.0F, new CubeDeformation(0.0F))
								.texOffs(0, 84).addBox(-3.25F, -34.0F, -13.5F, 20.0F, 23.0F, 27.0F, new CubeDeformation(0.0F)),
						PartPose.offset(39.25F, -39.25F, 0.0F));
		PartDefinition leftWrist = leftShoulder.addOrReplaceChild(
				"leftWrist", CubeListBuilder.create().texOffs(112, 118).mirror()
						.addBox(-11.0F, -3.0F, -8.0F, 22.0F, 22.0F, 16.0F, new CubeDeformation(0.0F)).mirror(false),
				PartPose.offset(15.25F, 15.0F, 0.0F));
		PartDefinition leftHand = leftWrist.addOrReplaceChild(
				"leftHand", CubeListBuilder.create().texOffs(298, 136).mirror()
						.addBox(-14.25F, -4.0F, -14.5F, 29.0F, 20.0F, 29.0F, new CubeDeformation(0.0F)).mirror(false),
				PartPose.offset(0.0F, 23.0F, 0.0F));
		PartDefinition leftFinger1 = leftHand.addOrReplaceChild(
				"leftFinger1", CubeListBuilder.create().texOffs(82, 37).mirror()
						.addBox(-1.5F, -1.0F, -2.5F, 3.0F, 10.0F, 5.0F, new CubeDeformation(0.0F)).mirror(false),
				PartPose.offset(6.5F, 17.0F, -5.0F));
		PartDefinition leftFinger2 = leftHand.addOrReplaceChild("leftFinger2", CubeListBuilder.create().texOffs(82, 37).mirror()
				.addBox(-1.5F, -1.0F, -2.5F, 3.0F, 10.0F, 5.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offset(6.5F, 17.0F, 5.0F));
		PartDefinition leftFinger3 = leftHand.addOrReplaceChild(
				"leftFinger3", CubeListBuilder.create().texOffs(82, 37).mirror()
						.addBox(-1.5F, -1.0F, -2.5F, 3.0F, 10.0F, 5.0F, new CubeDeformation(0.0F)).mirror(false),
				PartPose.offset(-5.5F, 17.0F, 0.0F));
		PartDefinition rightShoulder = upperBody.addOrReplaceChild("rightShoulder",
				CubeListBuilder.create().texOffs(0, 31).addBox(-16.75F, -34.0F, -13.5F, 20.0F, 23.0F, 27.0F, new CubeDeformation(0.0F))
						.texOffs(0, 184).addBox(-33.75F, -11.0F, -13.5F, 37.0F, 23.0F, 27.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-41.25F, -39.25F, 0.0F));
		PartDefinition rightWrist = rightShoulder.addOrReplaceChild("rightWrist",
				CubeListBuilder.create().texOffs(112, 118).addBox(-11.5F, -3.0F, -8.0F, 22.0F, 22.0F, 16.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-15.25F, 15.0F, 0.0F));
		PartDefinition rightHand = rightWrist.addOrReplaceChild("rightHand",
				CubeListBuilder.create().texOffs(283, 87).addBox(-15.0F, -4.0F, -14.5F, 29.0F, 20.0F, 29.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 23.0F, 0.0F));
		PartDefinition rightFinger1 = rightHand.addOrReplaceChild("rightFinger1",
				CubeListBuilder.create().texOffs(82, 37).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 10.0F, 5.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-6.5F, 17.0F, -5.0F));
		PartDefinition rightFinger2 = rightHand.addOrReplaceChild("rightFinger2",
				CubeListBuilder.create().texOffs(82, 37).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 10.0F, 5.0F, new CubeDeformation(0.0F)),
				PartPose.offset(5.5F, 17.0F, 0.0F));
		PartDefinition rightFinger3 = rightHand.addOrReplaceChild("rightFinger3",
				CubeListBuilder.create().texOffs(82, 37).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 10.0F, 5.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-6.5F, 17.0F, 5.0F));
		return LayerDefinition.create(meshdefinition, 512, 512);
	}

	@Override
	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green,
			float blue, float alpha) {
		leftLeg.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		rightLeg.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		lowerBody.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}
}
