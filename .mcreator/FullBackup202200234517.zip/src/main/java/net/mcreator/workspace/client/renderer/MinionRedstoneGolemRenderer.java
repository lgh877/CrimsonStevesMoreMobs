
package net.mcreator.workspace.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.workspace.entity.MinionRedstoneGolemEntity;
import net.mcreator.workspace.GolemAnimatedWardenRenderer;
import net.mcreator.workspace.GolemAnimatedWarden;

public class MinionRedstoneGolemRenderer
		extends
			GolemAnimatedWardenRenderer<MinionRedstoneGolemEntity, GolemAnimatedWarden<MinionRedstoneGolemEntity>> {
	public MinionRedstoneGolemRenderer(EntityRendererProvider.Context context) {
		super(context, new GolemAnimatedWarden(context.bakeLayer(GolemAnimatedWarden.LAYER_LOCATION)), 1f);
	}

	@Override
	public ResourceLocation getTextureLocation(MinionRedstoneGolemEntity entity) {
		return new ResourceLocation("workspace:textures/redstone-golem-on-planetminecraft-com.png");
	}
}
