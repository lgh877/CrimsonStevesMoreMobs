
package net.mcreator.workspace.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.workspace.entity.ZombieRavagerEntity;
import net.mcreator.workspace.client.model.ModelanimatedRavagerModel;

public class ZombieRavagerRenderer extends MobRenderer<ZombieRavagerEntity, ModelanimatedRavagerModel<ZombieRavagerEntity>> {
	public ZombieRavagerRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelanimatedRavagerModel(context.bakeLayer(ModelanimatedRavagerModel.LAYER_LOCATION)), 1.1f);
	}

	@Override
	public ResourceLocation getTextureLocation(ZombieRavagerEntity entity) {
		return new ResourceLocation("workspace:textures/entities/maw-beast-on-planetminecraft-com.png");
	}
}
