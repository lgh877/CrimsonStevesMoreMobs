
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.workspace.init;

import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.GameRules;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class WorkspaceModGameRules {
	public static final GameRules.Key<GameRules.BooleanValue> SHOULDSPAWNADDITIONALPATROLS = GameRules.register("shouldSpawnAdditionalPatrols",
			GameRules.Category.SPAWNING, GameRules.BooleanValue.create(true));
}
