
package net.mcreator.workspace.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.workspace.entity.CrudeRedstoneMonstrosityEntity;
import net.mcreator.workspace.GolemAnimatedWardenRenderer;
import net.mcreator.workspace.GolemAnimatedWarden;

public class CrudeRedstoneMonstrosityRenderer
		extends
			GolemAnimatedWardenRenderer<CrudeRedstoneMonstrosityEntity, GolemAnimatedWarden<CrudeRedstoneMonstrosityEntity>> {
	public CrudeRedstoneMonstrosityRenderer(EntityRendererProvider.Context context) {
		super(context, new GolemAnimatedWarden(context.bakeLayer(GolemAnimatedWarden.LAYER_LOCATION)), 1f);
	}

	@Override
	public ResourceLocation getTextureLocation(CrudeRedstoneMonstrosityEntity entity) {
		return new ResourceLocation("workspace:textures/redstone-monstrosity-on-planetminecraft-com.png");
	}
}
