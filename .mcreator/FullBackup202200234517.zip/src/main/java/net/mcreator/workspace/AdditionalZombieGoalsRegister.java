/**
 * The code of this mod element is always locked.
 *
 * You can register new events in this class too.
 *
 * If you want to make a plain independent class, create it using
 * Project Browser -> New... and make sure to make the class
 * outside net.mcreator.workspace as this package is managed by MCreator.
 *
 * If you change workspace package, modid or prefix, you will need
 * to manually adapt this file to these changes or remake it.
 *
 * This class will be added in the mod root package.
*/
package net.mcreator.workspace;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;

import net.minecraft.world.entity.raid.Raider;
import net.minecraft.world.entity.monster.PatrollingMonster;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.AbstractGolem;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.server.level.ServerLevel;

import net.mcreator.workspace.init.WorkspaceModGameRules;
import net.mcreator.workspace.init.WorkspaceModEntities;
import net.mcreator.workspace.entity.MinionRedstoneGolemEntity;
import net.mcreator.workspace.entity.CyborgVindicatorEntity;
import net.mcreator.workspace.entity.CrudeRedstoneGolemEntity;
import net.mcreator.workspace.entity.ChadVillagerEntity;

import java.util.function.Predicate;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
public class AdditionalZombieGoalsRegister {
	private static final Predicate<LivingEntity> LIVING_ENTITY_SELECTOR = (p_31504_) -> {
		return p_31504_.getMobType() == MobType.UNDEAD && p_31504_.attackable();
	};
	private static final Predicate<LivingEntity> ZOMBIE_LIVING_ENTITY_SELECTOR = (p_31504_) -> {
		return (p_31504_ instanceof Raider || p_31504_.getMobType() == MobType.ILLAGER) && p_31504_.attackable();
	};
	private static final Predicate<LivingEntity> ILLAGER_LIVING_ENTITY_SELECTOR = (p_31504_) -> {
		return !(p_31504_ instanceof Raider) && p_31504_.getMobType() == MobType.UNDEAD && p_31504_.attackable();
	};

	@SubscribeEvent
	public static void onEntityJoinWorld(final EntityJoinWorldEvent event) {
		if (event.getEntity() instanceof Mob zombie) {
			if (!(zombie instanceof Raider) && (zombie.getMobType() == MobType.UNDEAD) && zombie instanceof Enemy) {
				zombie.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(zombie, ChadVillagerEntity.class, true));
				zombie.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(zombie, AbstractGolem.class, true));
				zombie.targetSelector.addGoal(4, new NearestAttackableTargetGoal<>(zombie, Animal.class, true));
				zombie.targetSelector.addGoal(2,
						new NearestAttackableTargetGoal<>(zombie, LivingEntity.class, 0, false, false, ZOMBIE_LIVING_ENTITY_SELECTOR));
			}
		}
		if (event.getEntity() instanceof Mob zombie) {
			if ((zombie.getMobType() == MobType.ILLAGER || (zombie instanceof Raider)) && zombie instanceof Enemy) {
				zombie.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(zombie, ChadVillagerEntity.class, true));
				zombie.targetSelector.addGoal(2,
						new NearestAttackableTargetGoal<>(zombie, LivingEntity.class, 0, false, false, ILLAGER_LIVING_ENTITY_SELECTOR));
				zombie.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(zombie, AbstractGolem.class, true));
			}
		}
		if ((event.getEntity() instanceof PatrollingMonster mob) && (event.getEntity().level instanceof ServerLevel _level)) {
			if (!mob.getPersistentData().getBoolean("GloabalTriggerWasSpawnedInitially")) {
				mob.getPersistentData().putBoolean("GloabalTriggerWasSpawnedInitially", true);
				if (mob.level.getLevelData().getGameRules().getBoolean(WorkspaceModGameRules.SHOULDSPAWNADDITIONALPATROLS) && mob.isPatrolLeader()
						&& !_level.isRaided(mob.blockPosition())) {
					if (mob.level.dayTime() > 60000) {
						for (int i = 0; i < 4; i++) {
							MinionRedstoneGolemEntity entityToSpawn = new MinionRedstoneGolemEntity(WorkspaceModEntities.MINION_REDSTONE_GOLEM.get(),
									_level);
							entityToSpawn.moveTo(mob.getX(), mob.getY(), mob.getZ(), mob.getYRot(), mob.getXRot());
							entityToSpawn.setOwner(mob);
							entityToSpawn.setPatrolTarget(mob.getPatrolTarget());
							entityToSpawn.finalizeSpawn(_level, mob.level.getCurrentDifficultyAt(entityToSpawn.blockPosition()),
									MobSpawnType.MOB_SUMMONED, null, null);
							mob.level.addFreshEntity(entityToSpawn);
						}
					}
					if (mob.level.dayTime() > 120000 && mob.getType() != WorkspaceModEntities.CYBORG_VINDICATOR.get()) {
						CyborgVindicatorEntity entityToSpawn = new CyborgVindicatorEntity(WorkspaceModEntities.CYBORG_VINDICATOR.get(), _level);
						entityToSpawn.moveTo(mob.getX(), mob.getY(), mob.getZ(), mob.getYRot(), mob.getXRot());
						entityToSpawn.setPatrolTarget(mob.getPatrolTarget());
						entityToSpawn.setSize(10, true);
						mob.startRiding(entityToSpawn);
						mob.level.addFreshEntity(entityToSpawn);
					}
					if (mob.level.dayTime() > 360000) {
						for (int i = 0; i < 2; i++) {
							CrudeRedstoneGolemEntity entityToSpawn = new CrudeRedstoneGolemEntity(WorkspaceModEntities.CRUDE_REDSTONE_GOLEM.get(),
									_level);
							entityToSpawn.moveTo(mob.getX(), mob.getY(), mob.getZ(), mob.getYRot(), mob.getXRot());
							entityToSpawn.setPatrolTarget(mob.getPatrolTarget());
							mob.level.addFreshEntity(entityToSpawn);
						}
					}
				}
			}
		}
	}
}
