
package net.mcreator.workspace.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.workspace.entity.ZombieEvokerEntity;
import net.mcreator.workspace.WardenAnimatedIllagerModel;

public class ZombieEvokerRenderer extends MobRenderer<ZombieEvokerEntity, WardenAnimatedIllagerModel<ZombieEvokerEntity>> {
	public ZombieEvokerRenderer(EntityRendererProvider.Context context) {
		super(context, new WardenAnimatedIllagerModel(context.bakeLayer(WardenAnimatedIllagerModel.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(ZombieEvokerEntity entity) {
		return new ResourceLocation("workspace:textures/entities/zombie_evoker.png");
	}
}
