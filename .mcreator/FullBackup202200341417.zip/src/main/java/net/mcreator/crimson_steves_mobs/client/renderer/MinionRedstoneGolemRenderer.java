
package net.mcreator.crimson_steves_mobs.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.crimson_steves_mobs.entity.MinionRedstoneGolemEntity;
import net.mcreator.crimson_steves_mobs.GolemAnimatedWardenRenderer;
import net.mcreator.crimson_steves_mobs.GolemAnimatedWarden;

public class MinionRedstoneGolemRenderer
		extends
			GolemAnimatedWardenRenderer<MinionRedstoneGolemEntity, GolemAnimatedWarden<MinionRedstoneGolemEntity>> {
	public MinionRedstoneGolemRenderer(EntityRendererProvider.Context context) {
		super(context, new GolemAnimatedWarden(context.bakeLayer(GolemAnimatedWarden.LAYER_LOCATION)), 1f);
	}

	@Override
	public ResourceLocation getTextureLocation(MinionRedstoneGolemEntity entity) {
		return new ResourceLocation("crimson_steves_mobs:textures/redstone-golem-on-planetminecraft-com.png");
	}
}
