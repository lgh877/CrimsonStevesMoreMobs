
package net.mcreator.crimson_steves_mobs.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.crimson_steves_mobs.entity.CrudeRedstoneMonstrosityEntity;
import net.mcreator.crimson_steves_mobs.GolemAnimatedWardenRenderer;
import net.mcreator.crimson_steves_mobs.GolemAnimatedWarden;

public class CrudeRedstoneMonstrosityRenderer
		extends
			GolemAnimatedWardenRenderer<CrudeRedstoneMonstrosityEntity, GolemAnimatedWarden<CrudeRedstoneMonstrosityEntity>> {
	public CrudeRedstoneMonstrosityRenderer(EntityRendererProvider.Context context) {
		super(context, new GolemAnimatedWarden(context.bakeLayer(GolemAnimatedWarden.LAYER_LOCATION)), 1f);
	}

	@Override
	public ResourceLocation getTextureLocation(CrudeRedstoneMonstrosityEntity entity) {
		return new ResourceLocation("crimson_steves_mobs:textures/redstone-monstrosity-on-planetminecraft-com.png");
	}
}
