
package net.mcreator.crimson_steves_mobs.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.crimson_steves_mobs.entity.CrudeRedstoneGolemEntity;
import net.mcreator.crimson_steves_mobs.GolemAnimatedWardenRenderer;
import net.mcreator.crimson_steves_mobs.GolemAnimatedWarden;

public class CrudeRedstoneGolemRenderer extends GolemAnimatedWardenRenderer<CrudeRedstoneGolemEntity, GolemAnimatedWarden<CrudeRedstoneGolemEntity>> {
	public CrudeRedstoneGolemRenderer(EntityRendererProvider.Context context) {
		super(context, new GolemAnimatedWarden(context.bakeLayer(GolemAnimatedWarden.LAYER_LOCATION)), 1f);
	}

	@Override
	public ResourceLocation getTextureLocation(CrudeRedstoneGolemEntity entity) {
		return new ResourceLocation("crimson_steves_mobs:textures/redstone-golem-on-planetminecraft-com.png");
	}
}
