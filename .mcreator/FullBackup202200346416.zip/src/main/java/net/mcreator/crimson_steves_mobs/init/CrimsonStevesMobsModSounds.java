
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.crimson_steves_mobs.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.crimson_steves_mobs.CrimsonStevesMobsMod;

public class CrimsonStevesMobsModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, CrimsonStevesMobsMod.MODID);
	public static final RegistryObject<SoundEvent> REDSTONEGOLEM_HIT = REGISTRY.register("redstonegolem_hit",
			() -> new SoundEvent(new ResourceLocation("crimson_steves_mobs", "redstonegolem_hit")));
	public static final RegistryObject<SoundEvent> REDSTONEGOLEM_DEATH = REGISTRY.register("redstonegolem_death",
			() -> new SoundEvent(new ResourceLocation("crimson_steves_mobs", "redstonegolem_death")));
	public static final RegistryObject<SoundEvent> REDSTONEGOLEM_IDLE = REGISTRY.register("redstonegolem_idle",
			() -> new SoundEvent(new ResourceLocation("crimson_steves_mobs", "redstonegolem_idle")));
	public static final RegistryObject<SoundEvent> REDSTONEGOLEM_GROWL = REGISTRY.register("redstonegolem_growl",
			() -> new SoundEvent(new ResourceLocation("crimson_steves_mobs", "redstonegolem_growl")));
	public static final RegistryObject<SoundEvent> REDSTONEGOLEM_ELECTRIC = REGISTRY.register("redstonegolem_electric",
			() -> new SoundEvent(new ResourceLocation("crimson_steves_mobs", "redstonegolem_electric")));
	public static final RegistryObject<SoundEvent> REDSTONEGOLEM_STEP = REGISTRY.register("redstonegolem_step",
			() -> new SoundEvent(new ResourceLocation("crimson_steves_mobs", "redstonegolem_step")));
	public static final RegistryObject<SoundEvent> ENDERSENT_HURT = REGISTRY.register("endersent_hurt",
			() -> new SoundEvent(new ResourceLocation("crimson_steves_mobs", "endersent_hurt")));
	public static final RegistryObject<SoundEvent> ENDERSENT_DEATH = REGISTRY.register("endersent_death",
			() -> new SoundEvent(new ResourceLocation("crimson_steves_mobs", "endersent_death")));
	public static final RegistryObject<SoundEvent> ENDERSENT_IDLE = REGISTRY.register("endersent_idle",
			() -> new SoundEvent(new ResourceLocation("crimson_steves_mobs", "endersent_idle")));
	public static final RegistryObject<SoundEvent> ENDERSENT_STEP = REGISTRY.register("endersent_step",
			() -> new SoundEvent(new ResourceLocation("crimson_steves_mobs", "endersent_step")));
	public static final RegistryObject<SoundEvent> ROBOT_IDLE = REGISTRY.register("robot_idle",
			() -> new SoundEvent(new ResourceLocation("crimson_steves_mobs", "robot_idle")));
	public static final RegistryObject<SoundEvent> MONSTROSITY_IDLE = REGISTRY.register("monstrosity_idle",
			() -> new SoundEvent(new ResourceLocation("crimson_steves_mobs", "monstrosity_idle")));
	public static final RegistryObject<SoundEvent> MONSTROSITY_DEATH = REGISTRY.register("monstrosity_death",
			() -> new SoundEvent(new ResourceLocation("crimson_steves_mobs", "monstrosity_death")));
	public static final RegistryObject<SoundEvent> MONSTROSITY_HURT = REGISTRY.register("monstrosity_hurt",
			() -> new SoundEvent(new ResourceLocation("crimson_steves_mobs", "monstrosity_hurt")));
	public static final RegistryObject<SoundEvent> MONSTROSITY_STEP = REGISTRY.register("monstrosity_step",
			() -> new SoundEvent(new ResourceLocation("crimson_steves_mobs", "monstrosity_step")));
	public static final RegistryObject<SoundEvent> ROCK_SMASH = REGISTRY.register("rock_smash",
			() -> new SoundEvent(new ResourceLocation("crimson_steves_mobs", "rock_smash")));
	public static final RegistryObject<SoundEvent> ROCK_MATCH = REGISTRY.register("rock_match",
			() -> new SoundEvent(new ResourceLocation("crimson_steves_mobs", "rock_match")));
	public static final RegistryObject<SoundEvent> MONSTROSITY_SHOOT_2 = REGISTRY.register("monstrosity_shoot_2",
			() -> new SoundEvent(new ResourceLocation("crimson_steves_mobs", "monstrosity_shoot_2")));
	public static final RegistryObject<SoundEvent> MONSTROSITY_SHOOT = REGISTRY.register("monstrosity_shoot",
			() -> new SoundEvent(new ResourceLocation("crimson_steves_mobs", "monstrosity_shoot")));
	public static final RegistryObject<SoundEvent> CREESTEVE_HURT = REGISTRY.register("creesteve_hurt",
			() -> new SoundEvent(new ResourceLocation("crimson_steves_mobs", "creesteve_hurt")));
	public static final RegistryObject<SoundEvent> CREESTEVE_DEATH = REGISTRY.register("creesteve_death",
			() -> new SoundEvent(new ResourceLocation("crimson_steves_mobs", "creesteve_death")));
	public static final RegistryObject<SoundEvent> JEB_NOOOOO = REGISTRY.register("jeb_nooooo",
			() -> new SoundEvent(new ResourceLocation("crimson_steves_mobs", "jeb_nooooo")));
}
