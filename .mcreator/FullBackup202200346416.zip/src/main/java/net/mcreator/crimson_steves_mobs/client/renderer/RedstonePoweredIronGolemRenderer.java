
package net.mcreator.crimson_steves_mobs.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;

import net.mcreator.crimson_steves_mobs.entity.RedstonePoweredIronGolemEntity;
import net.mcreator.crimson_steves_mobs.AnimatedRedstoneGolemRenderer;
import net.mcreator.crimson_steves_mobs.AnimatedRedstoneGolemModel;

public class RedstonePoweredIronGolemRenderer
		extends
			AnimatedRedstoneGolemRenderer<RedstonePoweredIronGolemEntity, AnimatedRedstoneGolemModel<RedstonePoweredIronGolemEntity>> {
	public RedstonePoweredIronGolemRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedRedstoneGolemModel(context.bakeLayer(AnimatedRedstoneGolemModel.LAYER_LOCATION)), 1.1f);
		this.addLayer(new EyesLayer<RedstonePoweredIronGolemEntity, AnimatedRedstoneGolemModel<RedstonePoweredIronGolemEntity>>(this) {
			@Override
			public RenderType renderType() {
				return RenderType.eyes(new ResourceLocation("crimson_steves_mobs:textures/redstone_powered_golem_eyes.png"));
			}
		});
	}

	@Override
	public ResourceLocation getTextureLocation(RedstonePoweredIronGolemEntity entity) {
		return new ResourceLocation("crimson_steves_mobs:textures/redstone_powered_iron_golem.png");
	}
}
