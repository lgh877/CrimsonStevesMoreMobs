
package net.mcreator.crimson_steves_mobs.entity;

import net.minecraftforge.network.PlayMessages;
import net.minecraftforge.network.NetworkHooks;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.entity.projectile.ItemSupplier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.protocol.Packet;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import net.mcreator.crimson_steves_mobs.init.CrimsonStevesMobsModEntities;

@OnlyIn(value = Dist.CLIENT, _interface = ItemSupplier.class)
public class EarthQuakeExplosionEntity extends ThrowableItemProjectile {
	private static final EntityDataAccessor<Float> SIZE = SynchedEntityData.defineId(EarthQuakeExplosionEntity.class, EntityDataSerializers.FLOAT);
	//public float size = 2;
	public short shockRange = 10;
	public float damage = 5;
	public short shockSpeed = 5;
	public short yaw = 0;
	private Vec3 lookVec = this.getLookAngle();

	public EarthQuakeExplosionEntity(PlayMessages.SpawnEntity packet, Level world) {
		super(CrimsonStevesMobsModEntities.EARTH_QUAKE_EXPLOSION.get(), world);
	}

	public EarthQuakeExplosionEntity(EntityType<? extends EarthQuakeExplosionEntity> type, Level world) {
		super(type, world);
		//this.setInvisible(true);
		//this.refreshDimensions();
	}

	public EarthQuakeExplosionEntity(Level p_37399_, LivingEntity p_37400_) {
		super(CrimsonStevesMobsModEntities.EARTH_QUAKE_EXPLOSION.get(), p_37400_, p_37399_);
	}

	public EarthQuakeExplosionEntity(Level p_37394_, double p_37395_, double p_37396_, double p_37397_) {
		super(CrimsonStevesMobsModEntities.EARTH_QUAKE_EXPLOSION.get(), p_37395_, p_37396_, p_37397_, p_37394_);
	}

	public void addAdditionalSaveData(CompoundTag p_32304_) {
		super.addAdditionalSaveData(p_32304_);
		p_32304_.putShort("shockRange", this.shockRange);
		//p_32304_.putShort("lifeTime", this.lifeTime);
		p_32304_.putShort("shockSpeed", this.shockSpeed);
		p_32304_.putShort("yaw", this.yaw);
		p_32304_.putFloat("damage", this.damage);
		p_32304_.putFloat("size", this.entityData.get(SIZE));
	}

	public void readAdditionalSaveData(CompoundTag p_32296_) {
		super.readAdditionalSaveData(p_32296_);
		this.shockRange = p_32296_.getShort("shockRange");
		//this.lifeTime = p_32296_.getShort("lifeTime");
		this.shockSpeed = p_32296_.getShort("shockSpeed");
		this.yaw = p_32296_.getShort("yaw");
		this.damage = p_32296_.getFloat("damage");
		this.entityData.set(SIZE, p_32296_.getFloat("size"));
		this.lookVec = this.calculateViewVector(0, this.yaw);
	}

	protected void defineSynchedData() {
		super.defineSynchedData();
		this.entityData.define(SIZE, 1f);
	}

	public boolean isPickable() {
		return false;
	}

	public boolean isOnFire() {
		return false;
	}

	@Override
	public Packet<?> getAddEntityPacket() {
		return NetworkHooks.getEntitySpawningPacket(this);
	}

	protected Item getDefaultItem() {
		return Items.AIR;
	}

	public boolean isNoGravity() {
		return true;
	}

	protected BlockPos getNextPosition() {
		return new BlockPos(this.getX() + this.lookVec.x * this.entityData.get(SIZE), this.getY(),
				this.getZ() + this.lookVec.z * this.entityData.get(SIZE));
	}

	@Override
	public void tick() {
		super.tick();
		if (!this.level.isClientSide)
			if (this.tickCount % this.shockSpeed == 0) {
				this.lookVec = this.calculateViewVector(0, this.yaw);
				//this.moveTo(this.getX() + this.getLookAngle().x * size / 2, this.getY(), this.getZ() + this.getLookAngle().z * size / 2);
				BlockPos blockpos = this.getNextPosition();
				boolean flag = false;
				double d0 = 0.0D;
				do {
					BlockPos blockpos1 = blockpos.below();
					BlockState blockstate = this.level.getBlockState(blockpos1);
					if (blockstate.isFaceSturdy(this.level, blockpos1, Direction.UP)) {
						if (!this.level.isEmptyBlock(blockpos)) {
							BlockState blockstate1 = this.level.getBlockState(blockpos);
							VoxelShape voxelshape = blockstate1.getCollisionShape(this.level, blockpos);
							if (!voxelshape.isEmpty()) {
								d0 = voxelshape.max(Direction.Axis.Y);
							}
						}
						flag = true;
						break;
					}
					blockpos = blockpos.below();
				} while (blockpos.getY() >= Mth.floor(this.getY()) - 3);
				if (flag) {
					//this.setPos(this.getX() + this.lookVec.x * size / 2, blockpos.getY() + d0, this.getZ() + this.lookVec.z * size / 2);
					this.setPos(this.getX() + this.lookVec.x, blockpos.getY() + d0, this.getZ() + this.lookVec.z);
					Explosion.BlockInteraction explosion$blockinteraction = net.minecraftforge.event.ForgeEventFactory.getMobGriefingEvent(this.level,
							this) ? Explosion.BlockInteraction.DESTROY : Explosion.BlockInteraction.NONE;
					if (this.getOwner() != null) {
						this.level.explode(this.getOwner(), this.getX(), this.getY(), this.getZ(), this.entityData.get(SIZE),
								explosion$blockinteraction);
					}
				} else {
					this.discard();
				}
				if (this.shockRange > 0)
					this.shockRange--;
				else
					this.discard();
			}
	}

	public static EarthQuakeExplosionEntity shoot(Level world, LivingEntity entity, RandomSource random, int shockSpeed, float damage,
			int knockback) {
		EarthQuakeExplosionEntity entityarrow = new EarthQuakeExplosionEntity(world, entity);
		//entityarrow.setRot(0, entity.getYRot());
		entityarrow.moveTo(entity.getX(), entity.getY(), entity.getZ());
		/*
		entityarrow.getPersistentData().putFloat("size", 2);
		entityarrow.getPersistentData().putFloat("damage", 8);
		entityarrow.getPersistentData().putShort("shockRange", (short) 10);
		entityarrow.getPersistentData().putShort("shockSpeed", (short) 5);
		*/
		entityarrow.damage = damage;
		entityarrow.shockRange = 30;
		entityarrow.shockSpeed = (short) shockSpeed;
		//entityarrow.getPersistentData().putShort("yaw", (short) entity.getYRot());
		entityarrow.yaw = (short) (entity.getYRot() + ((random.nextFloat() - 0.5D) * knockback));
		world.addFreshEntity(entityarrow);
		return entityarrow;
	}

	public void setSize(float input) {
		this.entityData.set(SIZE, input);
	}

	public static EarthQuakeExplosionEntity shoot(Level world, LivingEntity entity, float damage, float size, int shockRange, int shockSpeed,
			float yaw) {
		EarthQuakeExplosionEntity entityarrow = new EarthQuakeExplosionEntity(world, entity);
		entityarrow.moveTo(entity.getX(), entity.getY(), entity.getZ());
		entityarrow.shockRange = (short) shockRange;
		entityarrow.shockSpeed = (short) shockSpeed;
		entityarrow.setSize(size);
		//entityarrow.size = size;
		entityarrow.damage = damage;
		entityarrow.yaw = (short) yaw;
		//entityarrow.moveTo(vec3);
		world.addFreshEntity(entityarrow);
		return entityarrow;
	}

	public static EarthQuakeExplosionEntity shoot(Level world, LivingEntity entity, float damage, float size, int shockRange, int shockSpeed,
			float yaw, Vec3 vec3) {
		EarthQuakeExplosionEntity entityarrow = new EarthQuakeExplosionEntity(world, entity);
		entityarrow.moveTo(vec3);
		entityarrow.shockRange = (short) shockRange;
		entityarrow.shockSpeed = (short) shockSpeed;
		entityarrow.setSize(size);
		entityarrow.damage = damage;
		entityarrow.yaw = (short) yaw;
		//entityarrow.moveTo(vec3);
		world.addFreshEntity(entityarrow);
		return entityarrow;
	}
}
