package net.mcreator.crimson_steves_mobs.init;

import net.mcreator.crimson_steves_mobs.CrimsonStevesMobsMod;
import net.minecraft.world.entity.raid.Raid;
import net.minecraftforge.event.level.LevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.apache.commons.lang3.ArrayUtils;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
public class HandleRaidersEvent {
    @SubscribeEvent
    public static void addRaidMembers(LevelEvent.Load event) {
        RaidWaveMembers.registerWaveMembers();
    }

    // remove our illagers from raids after leaving the world to prevent a post-mod-removal crash
    @SubscribeEvent
    public static void removeRaidMembers(LevelEvent.Unload event) {
        Raid.RaiderType[] members = Raid.RaiderType.values();
        for (Raid.RaiderType member : members) {
            if (RaidWaveMembers.CUSTOM_RAID_MEMBERS.contains(member)) {
                ArrayUtils.remove(members, member.ordinal());
                CrimsonStevesMobsMod.LOGGER.info("Removed " + member.name() + " from Raids to prevent a post-mod-removal crash");
            }
        }
    }
}
